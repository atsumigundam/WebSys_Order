<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>在庫詳細ページ</title>
</head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('/css/stockdetail.css')); ?>">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


<body>
	<div class="jumbotron">
		<div class="jumbocolor">
			<h1 class="display-3">在庫一覧</h1>
			<p class="lead">選択された本の詳細情報をお届けします</p>
		</div>
	</div>
	<div class="container bookcolor">
		<dic class ="bookdetail">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>参考画像</th>
							<th>タイトル</th>
							<th>作者</th>
							<th>出版社</th>
							<th>発行年月</th>
							<th>定価</th>
							<th>ISBN</th>
						</tr>
					</thead>

					<tbody>
						<tr>
							<td><img src="<?php echo e($cover); ?>"></td>
							<td><?php echo e($book); ?></td>
							<td><?php echo e($author); ?></td>
							<td><?php echo e($publisher); ?></td>
							<td><?php echo e($date); ?></td>
							<td><?php echo e($price); ?></td>
							<td><?php echo e($ISBN); ?></td>
						</tr>
					</tbody>

				</table>
			</div>
		</div>
	</div>

	<div class="container shopcolor">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>店舗</th>
							<th>在庫状況</th>
							<th>注文</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php echo e($shop1->name); ?></td>
							<td><?php echo e($zaiko1); ?></td>
							<td>
								<form action="order/<?php echo e($ISBN); ?>/<?php echo e($shop1->id); ?>" method="get">
									<button type = "submit" class="btn btn-secondary">
										注文へ
									</button>
								</form>
							</td>
						</tr>
						<tr>
							<td><?php echo e($shop2->name); ?></td>
							<td><?php echo e($zaiko2); ?></td>
							<td>
								<form action="order/<?php echo e($ISBN); ?>/<?php echo e($shop2->id); ?>" method="get" >
									<button type ="submit" class="btn btn-secondary">
										注文へ
									</button>
								</form>
							</td>
						</tr>
						<tr>
							<td><?php echo e($shop3->name); ?></td>
							<td><?php echo e($zaiko3); ?></td>
							<td>
								<form action="order/<?php echo e($ISBN); ?>/<?php echo e($shop3->id); ?>" method="get" >
									<button type ="submit" class="btn btn-secondary">
										注文へ
									</button>
								</form>
							</td>
						</tr>
						<tr>
							<td><?php echo e($shop4->name); ?></td>
							<td><?php echo e($zaiko4); ?></td>
							<td>
								<form action="order/<?php echo e($ISBN); ?>/<?php echo e($shop4->id); ?>" method="get" >
									<button type= "submit" class="btn btn-secondary">
										注文へ
									</button>
								</form>
							</td>
						</tr>
					</tbody>
				</table>													
			</div>
	</div>

</body>
</html>

