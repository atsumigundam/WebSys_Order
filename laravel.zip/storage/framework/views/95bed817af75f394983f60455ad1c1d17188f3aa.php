<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>検索結果</title>
</head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/list.css')); ?>">

<body>
	<div class="container">
		<?php $__currentLoopData = $books->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="row">
			<?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card col-md-3 shadow">
				<img class="card-img-top contain" src="<?php echo e(asset($book->cover)); ?>">
				<div class="card-block">
					<h4 class="card-title"><?php echo e($book->name); ?></h4>
					<p class="card-text"><?php echo e($book->price); ?>円(税抜)</p>
				</div>
				<a href="<?php echo e(url('/stocks', $book->ISBN)); ?>"></a>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="pagination row">
			<?php echo e($books->appends(['searchword' => $searchword])->links()); ?>

		</div>
		<div>
			<form action="search" method="get">
				<button class="btn btn-secondary" type="submit">検索トップへもどる</button>
			</form>
		</div>
	</div>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
</body>
</html>