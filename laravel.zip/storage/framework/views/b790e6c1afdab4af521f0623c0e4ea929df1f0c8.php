<?php $__env->startSection('title', '購入ログ分析'); ?>

<?php $__env->startSection('css'); ?>
	##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/searchlog.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<ul class="nav nav-tabs" id="myTab" role="tablist">
	<li class="nav-item">
		<a class="nav-link active" id="current-tab" data-toggle="tab" href="#current" role="tab" aria-controls="current" aria-selected="true">現在のデータ</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" id="past-tab" data-toggle="tab" href="#past" role="tab" aria-controls="past" aria-selected="false">過去のデータ</a>
	</li>
</ul>
<div class="tab-content" id="myTabContent">
	<div class="tab-pane fade show active" id="current" role="tabpanel" aria-labelledby="current-tab">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_purchase_book"></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card box mt-4" id="recent">
						<label>最近の注文</label>
						<div>
							<label><?php echo e($month_current); ?>月</label>
							<div class="card align-left">
								<label class="card-header access-header"><?php echo e($date); ?></label>
								<ul class="list-group list-group-flush">
									<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($book['id'] != 0): ?>
											<div id="accordion">
												<a href="#" class="list-group-item" id="<?php echo e($book['id']); ?>" data-toggle="collapse" data-target="#collapse_<?php echo e($book['id']); ?>" aria-expanded="true" aria-controls="collapse">
													<span class="badge badge-default"><?php echo e($book['time']); ?></span>
													<label class="no-margin"><?php echo e($book['name']); ?></label>
												</a>
												<div id="collapse_<?php echo e($book['id']); ?>" class="collapse" aria-labelledby="<?php echo e($book['id']); ?>" data-parent="#accordion">
											    	<div class="card-body">
											    		注文店: <?php echo e($book['shop']); ?>

											    	</div>
											    </div>
											</div>
										<?php else: ?>
											<div class="list-group-item">
												<label>---</label>
											</div>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_purchase_publisher"></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_purchase_price"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="tab-pane fade" id="past" role="tabpanel" aria-labelledby="past-tab">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_word_preview"></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_count_preview"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
	<script type="text/javascript">
		var month_current = <?php echo json_encode($month_current, 15, 512) ?>;
		var purchase_book = <?php echo json_encode($purchase_book, 15, 512) ?>;
		var purchase_publisher = <?php echo json_encode($purchase_publisher, 15, 512) ?>;
		var price_range = <?php echo json_encode($price_range, 15, 512) ?>;
	</script>
	<script type="text/javascript" src="<?php echo e(asset('js/chart_purchase.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.analysis', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>