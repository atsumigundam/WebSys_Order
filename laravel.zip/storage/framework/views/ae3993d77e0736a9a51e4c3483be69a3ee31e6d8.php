<?php $__env->startSection('title', '検索ログ分析'); ?>

<?php $__env->startSection('css'); ?>
	##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/searchlog.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="nav nav-tabs" id="myTab" role="tablist">
	<li class="nav-item">
		<a class="nav-link active" id="current-tab" data-toggle="tab" href="#current" role="tab" aria-controls="current" aria-selected="true">現在のデータ</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" id="past-tab" data-toggle="tab" href="#past" role="tab" aria-controls="past" aria-selected="false">過去のデータ</a>
	</li>
</ul>
<div class="tab-content" id="myTabContent">
	<div class="tab-pane fade show active" id="current" role="tabpanel" aria-labelledby="current-tab">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_word_current"></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_count_current"></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_word_multi"></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_no_hit_word"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="tab-pane fade" id="past" role="tabpanel" aria-labelledby="past-tab">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_word_preview"></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card box mt-4">
						<div id="chart_count_preview"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
	<script type="text/javascript">
		var word_current = <?php echo json_encode($word_current, 15, 512) ?>;
		var month_current = <?php echo json_encode($month_current, 15, 512) ?>;
		var count_current = <?php echo json_encode($count_current, 15, 512) ?>;
		var word_multi = <?php echo json_encode($word_multi, 15, 512) ?>;
		var no_hit_word = <?php echo json_encode($no_hit_word, 15, 512) ?>;
	</script>
	<script type="text/javascript" src="<?php echo e(asset('js/chart.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.analysis', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>